import urllib.request
import urllib.parse
import json
import re
from datetime import date, datetime

SUPABASE_URL = "https://tonqfgeyxnnwicjopshn.supabase.co"
SUPABASE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InRvbnFmZ2V5eG5ud2ljam9wc2huIiwicm9sZSI6InNlcnZpY2Vfcm9sZSIsImlhdCI6MTc3ODY2Njc3MSwiZXhwIjoyMDk0MjQyNzcxfQ.pXo3eRA64XTmjXzMgoNUUNss7xDJnmfcWOvImUG0isQ"

# 47只板块ETF，腾讯格式：sh/sz+代码
# 说明：sz883410 / sz886078 / sz885939 是同花顺自有指数，腾讯接口无数据
# 需通过 ths_fetch 单独获取
ETF_TX_CODES = [
    'sz159611','sz159227','sz159309','sh560280','sz159996',
    'sh515220','sz159666','sh167301','sh515880','sh515750',
    'sz159842','sz159857','sh518880','sh516390','sh560780',
    'sh562500','sz159819','sz159875','sz159608','sh515400',
    'sh515230','sz159825','sh516910','sz159869','sh515120',
    'sh512660','sz159887','sz159766','sh563010','sz159995',
    'sh516780','sh512200','sh516620','sh512690','sh560800',
    'sh516100','sh512480','sh515150','sz159206','sh560860',
    'sh561160','sz159732','sh562600','sh516510','sz159998',
    # 以下3个同花顺自有指数，腾讯接口拿不到，单独用 THS 接口
    # 'sz886078','sz885939',  <- 移出TX批量列表
]

# 大盘ETF
INDEX_ETF_TX = ['sh510050','sh510300','sh510500','sh512100']

# 同花顺自有指数代码（不含交易所前缀）
THS_INDEX_CODES = ['883410', '886078', '885939']


def tx_fetch(codes):
    """
    腾讯行情接口，批量获取
    返回 {code: {'price':x, 'last_close':x, 'pct':x, 'name':x}}
    """
    batch = ','.join(codes)
    url = f"http://qt.gtimg.cn/q={batch}"
    req = urllib.request.Request(url, headers={
        'Referer': 'http://gu.qq.com/',
        'User-Agent': 'Mozilla/5.0',
    })
    result = {}
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            text = resp.read().decode('gbk', errors='ignore')
        if codes:
            print(f"tx_fetch sample: {text[:200]}")
        for line in text.strip().split('\n'):
            m = re.match(r'v_(\w+)="([^"]*)"', line)
            if not m:
                continue
            code = m.group(1)
            fields = m.group(2).split('~')
            # 腾讯行情字段（~分隔）：
            # 0=名称 1=代码 2=现价 3=昨收 4=今开 5=成交量 6=涨跌额 7=... 32=涨跌幅
            if len(fields) < 10:
                continue
            try:
                price = float(fields[3]) if fields[3] else 0
                last_close = float(fields[4]) if fields[4] else 0
                pct_str = fields[32] if len(fields) > 32 else '0'
                pct = float(pct_str) if pct_str else 0
                if last_close > 0:
                    result[code] = {
                        'price': price,
                        'last_close': last_close,
                        'pct': pct,
                        'name': fields[1] if len(fields) > 1 else ''
                    }
            except (ValueError, IndexError):
                pass
    except Exception as e:
        print(f"tx_fetch error: {e}")
    return result


def ths_fetch(codes):
    """
    同花顺行情接口，获取自有指数（883410/886078/885939 等）
    接口：http://d.10jqka.com.cn/v4/time/hs_{code}/last.js
    返回 {code: {'price':x, 'last_close':x, 'pct':x}}

    响应示例（JSONP）：
      quotebridge_v4_time_hs_883410_last({"name":"...", "c":"4321.5", "zs":"4200.0", ...})
    字段说明：
      c  = 当前价（收盘/最新价）
      zs = 昨收（基准价）
      zd = 涨跌幅（如 "2.89"，单位%）
    """
    result = {}
    for code in codes:
        url = f"http://d.10jqka.com.cn/v4/time/hs_{code}/last.js"
        req = urllib.request.Request(url, headers={
            'Referer': 'http://www.10jqka.com.cn/',
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        })
        try:
            with urllib.request.urlopen(req, timeout=10) as resp:
                raw = resp.read().decode('utf-8', errors='ignore')
            print(f"ths_fetch {code} raw: {raw[:300]}")
            # 去掉 JSONP 包装，提取 JSON 部分
            m = re.search(r'\((\{.*\})\)', raw, re.DOTALL)
            if not m:
                # 有时直接是 JSON
                m = re.search(r'(\{.*\})', raw, re.DOTALL)
            if not m:
                print(f"ths_fetch {code}: no JSON found")
                continue
            data = json.loads(m.group(1))
            # 字段取值
            price_str = data.get('c') or data.get('price') or ''
            zs_str    = data.get('zs') or data.get('yestclose') or ''
            zd_str    = data.get('zd') or data.get('increase') or ''
            if not price_str:
                print(f"ths_fetch {code}: empty price")
                continue
            price      = float(price_str)
            last_close = float(zs_str) if zs_str else 0
            pct        = float(zd_str) if zd_str else 0
            # 若 last_close 为0，用 price 倒推（pct 不为0时）
            if last_close <= 0 and pct != 0:
                last_close = price / (1 + pct / 100)
            result[code] = {
                'price': price,
                'last_close': last_close,
                'pct': pct,
                'name': data.get('name', code)
            }
            print(f"ths_fetch {code}: price={price}, last_close={last_close}, pct={pct}")
        except Exception as e:
            print(f"ths_fetch {code} error: {e}")
    return result


def fetch_duoban(ths_data):
    """
    多板指数涨跌幅，来源：同花顺 883410（已在 ths_data 中）
    """
    item = ths_data.get('883410')
    if item:
        return item.get('pct')
    return None


def supabase_upsert(table, data):
    url = f"{SUPABASE_URL}/rest/v1/{table}"
    body = json.dumps(data).encode('utf-8')
    req = urllib.request.Request(url, data=body, method='POST', headers={
        'Content-Type': 'application/json',
        'apikey': SUPABASE_KEY,
        'Authorization': f'Bearer {SUPABASE_KEY}',
        'Prefer': 'resolution=merge-duplicates'
    })
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            print(f"upsert status: {resp.status}")
            return resp.status
    except Exception as e:
        print(f"Supabase upsert error: {e}")
        return None


def supabase_select(table, params):
    query = urllib.parse.urlencode(params)
    url = f"{SUPABASE_URL}/rest/v1/{table}?{query}"
    req = urllib.request.Request(url, method='GET', headers={
        'apikey': SUPABASE_KEY,
        'Authorization': f'Bearer {SUPABASE_KEY}',
    })
    try:
        with urllib.request.urlopen(req, timeout=10) as resp:
            return json.loads(resp.read())
    except Exception as e:
        print(f"Supabase select error: {e}")
        return []


def main_handler(event, context):
    today = date.today().isoformat()
    now_time = datetime.now().strftime('%H:%M:%S')
    print(f"=== market_snapshot {today} {now_time} ===")

    # ── 1. 先获取同花顺自有指数（883410/886078/885939）
    ths_data = ths_fetch(THS_INDEX_CODES)

    # ── 2. 多板% = 883410 涨跌幅
    duoban_pct = fetch_duoban(ths_data)
    print(f"duoban_pct: {duoban_pct}")

    # ── 3. 板块ETF红数
    #    45只从腾讯接口取（分批，每次50个）
    etf_red = 0
    etf_total = 0
    for i in range(0, len(ETF_TX_CODES), 50):
        batch = ETF_TX_CODES[i:i+50]
        data = tx_fetch(batch)
        etf_total += len(data)
        etf_red += sum(1 for q in data.values() if q['price'] > q['last_close'])

    #    886078 / 885939 从同花顺接口取
    for code in ['886078', '885939']:
        item = ths_data.get(code)
        if item:
            etf_total += 1
            if item['price'] > item['last_close']:
                etf_red += 1
        else:
            print(f"ths {code}: no data, skipped from ETF count")

    print(f"ETF red: {etf_red}/{etf_total}")

    # ── 4. 大盘ETF均值（腾讯接口）
    idx_data = tx_fetch(INDEX_ETF_TX)
    idx_pcts = [q['pct'] for q in idx_data.values() if q['last_close'] > 0]
    index_etf_avg = round(sum(idx_pcts)/len(idx_pcts), 2) if idx_pcts else None
    print(f"Index ETF avg: {index_etf_avg} from {len(idx_pcts)} ETFs")

    # ── 5. 大盘% 上证指数（腾讯接口）
    mkt_data = tx_fetch(['sh000001'])
    market_pct = None
    if 'sh000001' in mkt_data:
        market_pct = mkt_data['sh000001'].get('pct')
    print(f"Market pct: {market_pct}")

    # ── 6. 昨日前五红数（Supabase top5_cache）
    top5_red = None
    rows = supabase_select('top5_cache', {'trade_date': f'eq.{today}', 'select': 'codes'})
    if rows:
        codes_str = rows[0].get('codes', '')
        print(f"top5 codes: {codes_str}")
        if codes_str:
            top5_codes = codes_str.split(',')  # 格式已是 sh600000
            top5_data = tx_fetch(top5_codes)
            top5_red = sum(1 for q in top5_data.values() if q['price'] > q['last_close'])
            print(f"Top5 red: {top5_red}/{len(top5_data)}")
    else:
        print("WARNING: top5_cache empty for today")

    record = {
        'trade_date': today,
        'snapshot_time': now_time,
        'duoban_pct': duoban_pct,
        'etf_red_count': etf_red,
        'top5_red_count': top5_red,
        'index_etf_avg': index_etf_avg,
        'market_pct': market_pct,
    }
    print(f"Saving: {record}")
    supabase_upsert('market_snapshot', record)

    return {'status': 'ok', 'record': record}
